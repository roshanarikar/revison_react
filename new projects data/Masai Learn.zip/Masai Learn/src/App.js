import './App.css';
import { AllRoutes } from './components/AllRoutes';

function App() {
  return (
      <div>
        <AllRoutes/>
      </div>
  );
}

export default App;
